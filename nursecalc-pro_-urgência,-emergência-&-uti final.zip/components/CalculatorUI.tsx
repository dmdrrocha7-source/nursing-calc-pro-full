
import React from 'react';
import { MultiSelectOption, ClinicalPearls } from '../types';

interface ScoreSelectorProps {
  sections: MultiSelectOption[];
  onValuesChange: (values: number[]) => void;
}

export const ScoreSelector: React.FC<ScoreSelectorProps> = ({ sections, onValuesChange }) => {
  const [selected, setSelected] = React.useState<number[]>(new Array(sections.length).fill(0));

  const handleChange = (sectionIdx: number, val: number) => {
    const newSelected = [...selected];
    newSelected[sectionIdx] = val;
    setSelected(newSelected);
    onValuesChange(newSelected);
  };

  return (
    <div className="space-y-4">
      {sections.map((section, idx) => (
        <div key={idx} className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-sm transition-shadow">
          <h3 className="font-bold text-slate-700 text-sm mb-3 flex items-center gap-2">
            <span className="w-5 h-5 bg-slate-100 text-slate-500 rounded-md flex items-center justify-center text-[10px]">{idx + 1}</span>
            {section.title}
          </h3>
          <div className="flex flex-wrap gap-2">
            {section.options.map((opt, optIdx) => (
              <button
                key={optIdx}
                onClick={() => handleChange(idx, opt.value)}
                className={`flex-1 min-w-[120px] text-center px-3 py-2.5 rounded-lg text-xs font-medium border transition-all ${
                  selected[idx] === opt.value 
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-md' 
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export const AlertBox: React.FC<{ title: string; children: React.ReactNode; type?: 'info' | 'warning' | 'danger' }> = ({ title, children, type = 'info' }) => {
  const styles = {
    info: 'bg-blue-50 border-blue-100 text-blue-800',
    warning: 'bg-amber-50 border-amber-100 text-amber-800',
    danger: 'bg-red-50 border-red-100 text-red-800',
  };

  return (
    <div className={`mt-4 p-4 rounded-xl border ${styles[type]}`}>
      <div className="flex items-center gap-2 mb-1.5 font-black uppercase text-[10px] tracking-widest">
        <i className={`fas ${type === 'danger' ? 'fa-triangle-exclamation' : 'fa-circle-info'}`}></i>
        {title}
      </div>
      <div className="text-sm font-medium leading-relaxed">
        {children}
      </div>
    </div>
  );
};

export const ClinicalPearlsSection: React.FC<{ data: ClinicalPearls; currentScore: number }> = ({ data, currentScore }) => {
  const getDynamicGuidance = () => {
    if (!data.dynamic) return data.static;
    const match = data.dynamic.find(d => currentScore >= d.min && currentScore <= d.max);
    return match || data.dynamic[data.dynamic.length - 1]; // Default to last if no match
  };

  const guidance = getDynamicGuidance();

  if (!guidance) return null;

  return (
    <div className="mt-8 space-y-4 animate-fadeIn">
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-sm">
        <h3 className="font-black text-slate-800 mb-4 flex items-center gap-2 text-sm uppercase tracking-wider">
          <i className="fas fa-lightbulb text-amber-400"></i>
          Pérolas & Pitfalls (Escore: {currentScore})
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <h4 className="text-[10px] font-black text-emerald-600 uppercase border-b border-emerald-100 pb-1">Pérolas de Prática</h4>
            <ul className="text-xs text-slate-600 space-y-2 list-disc pl-4 leading-relaxed">
              {guidance.pearls.map((p, i) => <li key={i}>{p}</li>)}
            </ul>
          </div>
          <div className="space-y-3">
            <h4 className="text-[10px] font-black text-rose-600 uppercase border-b border-rose-100 pb-1">Riscos & Alertas (Pitfalls)</h4>
            <ul className="text-xs text-slate-600 space-y-2 list-disc pl-4 leading-relaxed">
              {guidance.pitfalls.map((p, i) => <li key={i}>{p}</li>)}
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-6 shadow-sm">
        <h3 className="font-black text-indigo-800 mb-4 flex items-center gap-2 text-sm uppercase tracking-wider">
          <i className="fas fa-hand-holding-medical"></i>
          Processo de Cuidados de Enfermagem
        </h3>
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3">
          {guidance.nursingCare.map((c, i) => (
            <li key={i} className="text-[11px] text-indigo-700 font-medium flex items-start gap-2 bg-white/50 p-2 rounded-lg border border-indigo-100/50">
              <span className="mt-1 w-2 h-2 bg-indigo-400 rounded-full flex-shrink-0"></span>
              {c}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
