
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  onHome: () => void;
  title: string;
}

const Layout: React.FC<LayoutProps> = ({ children, onHome, title }) => {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 bg-indigo-700 text-white shadow-lg p-4 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={onHome}>
          <i className="fas fa-hand-holding-medical text-2xl"></i>
          <h1 className="font-bold text-lg hidden sm:block tracking-tight">NurseCalc Pro</h1>
          <h1 className="font-bold text-lg sm:hidden">NCP</h1>
        </div>
        <div className="text-center font-medium truncate max-w-[50%]">
          {title}
        </div>
        <button 
          onClick={onHome}
          className="bg-indigo-600 hover:bg-indigo-500 transition-colors px-3 py-1 rounded-lg text-sm flex items-center gap-2"
        >
          <i className="fas fa-house"></i>
          <span className="hidden md:inline">Início</span>
        </button>
      </header>
      
      <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full">
        {children}
      </main>

      <footer className="bg-slate-100 border-t p-4 text-center text-xs text-slate-500">
        <p>Baseado em PHTLS, ATLS, ACLS, PALS e AHA 2025. Uso restrito a profissionais de saúde.</p>
      </footer>
    </div>
  );
};

export default Layout;
